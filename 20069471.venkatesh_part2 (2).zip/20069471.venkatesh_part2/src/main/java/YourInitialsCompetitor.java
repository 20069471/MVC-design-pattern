 package com.yourpackage; // Replace with your actual package name

public class YourInitialsCompetitor {
    import java.util.Arrays;

public class YourInitialsCompetitor {
    private int competitorNumber;
    private String name;
    private String country;
    private String level;
    private int age;
    private double[] scores;

    // Constructor
    public YourInitialsCompetitor(int competitorNumber, String name, String country, String level, int age, double[] scores) {
        this.competitorNumber = competitorNumber;
        this.name = name;
        this.country = country;
        this.level = level;
        this.age = age;
        this.scores = scores;
    }

    // Getter and Setter methods

    public double getOverallScore() {
        // Simple average for demonstration purposes
        double sum = Arrays.stream(scores).sum();
        return sum / scores.length;
    }

    public String getFullDetails() {
        return String.format("Competitor number %d, name %s, country %s.\n%s is a %s aged %d and has an overall score of %.2f.\nReceived these scores: %s",
                competitorNumber, name, country, name, level, age, getOverallScore(), Arrays.toString(scores));
    }

    public String getShortDetails() {
        return String.format("CN %d (%s) has an overall score %.2f.", competitorNumber, getInitials(), getOverallScore());
    }

    public double[] getScoreArray() {
        return scores;
    }

    private String getInitials() {
        String[] nameParts = name.split(" ");
        StringBuilder initials = new StringBuilder();

        for (String part : nameParts) {
            initials.append(part.charAt(0));
        }

        return initials.toString();
    }

    public static void main(String[] args) {
        // Example usage and testing
        double[] exampleScores = {5, 4, 5, 4, 3};
        YourInitialsCompetitor competitor = new YourInitialsCompetitor(100, "Keith John Talbot", "UK", "Novice", 21, exampleScores);

        System.out.println(competitor.getFullDetails());
        System.out.println(competitor.getShortDetails());
        System.out.println("Score Array: " + Arrays.toString(competitor.getScoreArray()));
    }
}

    
}
