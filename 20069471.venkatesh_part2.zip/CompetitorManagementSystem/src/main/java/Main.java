import java.util.ArrayList;

public class Competitor {
    private int competitorNumber;
    private String name;
    private int age;

    public Competitor(int competitorNumber, String name, int age) {
        this.competitorNumber = competitorNumber;
        this.name = name;
        this.age = age;
    }

    @Override
    public String toString() {
        return "Competitor{" +
                "competitorNumber=" + competitorNumber +
                ", name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}

class CompetitorList {
    private ArrayList<Competitor> competitors;

    public CompetitorList() {
        competitors = new ArrayList<>();
    }

    public void addCompetitor(Competitor competitor) {
        competitors.add(competitor);
    }

    public void displayCompetitors() {
        for (Competitor competitor : competitors) {
            System.out.println(competitor);
        }
    }
}

class Main {
    public static void main(String[] args) {
        CompetitorList competitorList = new CompetitorList();

        Competitor competitor1 = new Competitor(1, "John Doe", 25);
        Competitor competitor2 = new Competitor(2, "Jane Smith", 30);

        competitorList.addCompetitor(competitor1);
        competitorList.addCompetitor(competitor2);

        System.out.println("Competitors:");
        competitorList.displayCompetitors();
    }
}
