public class Competitor {
    // Common attributes and methods
}

public class YourInitialsCompetitor extends Competitor {
    // Specific attributes and methods for YourInitialsCompetitor
}

// Implement a GUI using JavaFX or another GUI library
// ...

public class CompetitorGUI {
    private CompetitorList competitorList;

    public CompetitorGUI(CompetitorList competitorList) {
        this.competitorList = competitorList;
    }

    public void run() {
        // Implement GUI logic
        // ...
    }
}

public class MainStage5 {
    public static void main(String[] args) {
        CompetitorList competitorList = new CompetitorList();
        CompetitorGUI competitorGUI = new CompetitorGUI(competitorList);

        // Run the GUI
        competitorGUI.run();
    }
}
